## hosted-smoke.ts

```typescript
import { HostedHarnessProcess, HOSTED_CLI, HOSTED_TOKEN, HOSTED_DIGEST } from '../../../integration-tests/helpers/hosted-harness-process.ts';
import { startHostedSessionStore } from '../../../integration-tests/helpers/hosted-session-store.ts';
import { randomUUID } from 'node:crypto';
import { writeFileSync,readFileSync,existsSync } from 'node:fs';
import { resolve } from 'node:path';
import assert from 'node:assert/strict';
const out=resolve('.qwen/e2e-tests/catalog-test-isolation');
const ledger=resolve(out,'hosted-socket.jsonl');
const tap=resolve(out,'socket-tap.mjs');
writeFileSync(ledger,'');
writeFileSync(tap,`
import net from 'node:net';
import {appendFileSync} from 'node:fs';
const file=${JSON.stringify(ledger)};
const log=x=>appendFileSync(file,JSON.stringify(x)+'\\n');
log({kind:'env',refresh:process.env.QWEN_CODE_MODELS_DEV_REFRESH??null,home:process.env.HOME,qwenHome:process.env.QWEN_HOME,callerOnly:process.env.HOSTED_CALLER_ONLY??null});
const original=net.Socket.prototype.connect;
net.Socket.prototype.connect=function(...args){let first=args[0];if(Array.isArray(first))first=first[0];const o=typeof first==='object'?first:{port:first,host:typeof args[1]==='string'?args[1]:'localhost'};if(o.port){const host=o.host??o.hostname??'localhost';const local=['localhost','127.0.0.1','::1'].includes(host);log({kind:'connect',host,port:o.port,local});if(!local)throw new Error('Verification blocked external socket: '+host);}return original.apply(this,args);};
`);
process.env.QWEN_CODE_MODELS_DEV_REFRESH='on';
process.env.HOSTED_CALLER_ONLY='must-not-leak';
process.env.QWEN_HOME='caller-poison-home';
const cli=new HostedHarnessProcess();const sessionId=randomUUID();const store=await startHostedSessionStore(sessionId);let result:Record<string,unknown>={};
try {
 await cli.start('http://127.0.0.1:59999/v1',{args:['--import',tap,HOSTED_CLI,'serve','--profile','hosted-harness','--http-bridge','--no-web','--hostname','127.0.0.1','--port','0','--token',HOSTED_TOKEN,'--hosted-harness-capability-digest',HOSTED_DIGEST]});
 const caps=await cli.request('/capabilities');assert.equal(caps.status,200);
 const response=await cli.request('/session',{method:'POST',headers:{...cli.headers(),'Content-Type':'application/json'},body:JSON.stringify({sessionId,sessionScope:'thread',managedSessionStore:{baseUrl:store.baseUrl,tenantId:'tenant',workspaceId:'workspace',writerId:cli.bootId,leaseDurationMs:60000}})});
 const body=await response.text();assert.equal(response.status,200,body);
 await new Promise(r=>setTimeout(r,1000));
 const lines=readFileSync(ledger,'utf8').trim().split('\n').map(x=>JSON.parse(x));
 const env=lines.find(x=>x.kind==='env');const attempts=lines.filter(x=>x.kind==='connect');assert.equal(env.refresh,'off');assert.equal(env.callerOnly,null);assert.equal(env.home,cli.root);assert(attempts.some(x=>x.local));assert.equal(attempts.filter(x=>!x.local).length,0);
 result={status:'PASS',capabilities:caps.status,session:response.status,childEnv:env,socketAttempts:attempts.length,externalAttempts:0,root:cli.root,modelPromptsSent:0};
} catch(error){result={status:'FAIL',error:String(error),root:cli.root};throw error;} finally {writeFileSync(resolve(out,'hosted-output.log'),cli.output);await cli.close();await store.close();result.cleanup={rootRemoved:!existsSync(cli.root),childExited:cli.child?.exitCode!==null||cli.child?.signalCode!==null};writeFileSync(resolve(out,'hosted-smoke-result.json'),JSON.stringify(result,null,2));}

```

## socket-tap.mjs

```typescript

import net from 'node:net';
import {appendFileSync} from 'node:fs';
const file="$WORKTREE/.qwen/e2e-tests/catalog-test-isolation/hosted-socket.jsonl";
const log=x=>appendFileSync(file,JSON.stringify(x)+'\n');
log({kind:'env',refresh:process.env.QWEN_CODE_MODELS_DEV_REFRESH??null,home:process.env.HOME,qwenHome:process.env.QWEN_HOME,callerOnly:process.env.HOSTED_CALLER_ONLY??null});
const original=net.Socket.prototype.connect;
net.Socket.prototype.connect=function(...args){let first=args[0];if(Array.isArray(first))first=first[0];const o=typeof first==='object'?first:{port:first,host:typeof args[1]==='string'?args[1]:'localhost'};if(o.port){const host=o.host??o.hostname??'localhost';const local=['localhost','127.0.0.1','::1'].includes(host);log({kind:'connect',host,port:o.port,local});if(!local)throw new Error('Verification blocked external socket: '+host);}return original.apply(this,args);};

```

