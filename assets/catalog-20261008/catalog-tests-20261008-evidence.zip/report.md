# Catalog test-isolation verification

**Verdict: PASS**

UI: **N/A**. This follow-up changes test-process isolation and catalog-sensitive assertions. Previous real catalog TUI verification is separate.

Runtime identity: base `fe4d4e345c3f52fd6d8455646cdd3c782ca8b227` + frozen diff SHA256 `0d0b61cbcca5e0b0ea93f8c00e35ebcd45f56a23495857ad08dd19e6880c6876`. `identity.json` records helper/test hashes and1073split-bundle JS hashes. The enhanced Hosted test is byte-identical before/after; all bundle JS files remained byte-identical.

| Check | Observed result |
| --- | --- |
| Hosted before |Exit1:1genuine assertion failure,8skipped/9collected. Caller refresh=on; child value null versus expected off. Child exit0; cleanup completed.|
| Hosted after |Exit0:1passed,8skipped/9collected, same test command/source.|
| Real Hosted startup and session |/capabilities200 and/session200, child refresh=off, clean HOME/QWEN_HOME, caller-only variable absent.|
| Socket-level causal witness |2real127.0.0.1 connections to the local session store;0external attempts;0model prompts.|
| Resource cleanup |Child exited; temporary Hosted home deleted; fixture store closed.|
| VSCode poisoned-parent control |15passes with parent catalogOFF and future gpt-4o999999 cache; tests still derive bundled128000. Temporary poison directory removed.|
| VSCode regression pin |Root's inspected negative-control artifacts show2assertion failures/13passes with compiled catalog lookup disabled; dependency restored byte-identically.|

Focused Hosted command (cwd `integration-tests`), unchanged between arms:

```sh
npx vitest run --config vitest.hosted.config.ts cli/hosted-harness-process.test.ts -t "keeps the caller" --retry 0
```

VSCode command (cwd `packages/vscode-ide-companion`):

```sh
../../node_modules/.bin/vitest run src/utils/acpModelInfo.test.ts
```

Its exact poison environment/cache is in `vscode-poison-result.json`. The real Hosted smoke ran `./node_modules/.bin/tsx .qwen/e2e-tests/catalog-test-isolation/hosted-smoke.ts`, using the existing helper and store fixture. A temporary Node --import tap observed actual Socket.connect calls, rejected any nonloopback attempt, and recorded child environment. Positive local-store connections prove the tap was active. Raw ledger is `hosted-socket.jsonl`; full outcomes and cleanup are in `hosted-smoke-result.json`. Runnable harness files were removed after archiving to `harness-source.md`.

Evidence: `before-focus.log`, `after-focus.log`, `hosted-output.log`, `hosted-socket.jsonl`, `vscode-poison.log`, `identity.json`. Root-owned negative control: `vscode-negative-control.log/json`; inspected rather than re-executed by test engineer.

Limitations: no live backend or generation request; no claim that every integration path is covered. No product/test source changes, dependency installation, builds, broad suites or GitHub publication by test engineer.
