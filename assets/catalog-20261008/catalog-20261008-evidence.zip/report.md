# Catalog follow-up UI verification

Local UI verification: **PASS**

- Mode: current-main evidence check plus matched merge-reference for #13414.
- Before: `fe4d4e345c3f52fd6d8455646cdd3c782ca8b227`.
- Candidate: same base + frozen `fix-review.patch`, SHA256 `d0e722a6648d512c0552814da0684bc80180fa99d9ad8603426524a65d17d98c` (not a committed candidate SHA at verification time).
- Runtime: `/opt/homebrew/bin/node .../qwen-code-catalog-followup/dist/cli.js`; full split-bundle JS manifests in `before-runtime.json` and `after-runtime.json`; exact per-profile command/env in `identity.json`.
- Surface: actual tmux120x40 keystrokes, primary pane/ANSI/readable logs, individually inspected TerminalCapture PNGs; recording HTTP loopback fixture and cache hashes.

| Behavior | Before | Candidate | Verdict |
| --- | --- | --- | --- |
| GLM dotted control `/context` |64000|64000|PASS|
| GLM dashed `/context` |202752|64000|PASS:fixed|
| Identical valid PNG through real @file consumer |dotted image1/output16384; dashed image0/output32000|both image1/output16384|PASS:fixed|
| Old cache projection upgrade |projection1→2 full GET|projection2→3 full GET, no If-None-Match|PASS|
| Running process and restart |warm256000/output32000; restart131072/output16384|same limits; cache projection3|PASS|
| Invalid JSON refresh |old cache SHA retained;222222 context|old cache SHA retained;222222 context|PASS|
| Connection refusal |not separately run on base|ECONNREFUSED63053; old projection2 cache SHA retained; bundled1M usable|PASS|
| Explicit context during refresh/restart |warm131072|warm and restart131072 while cache777777|PASS|
| Existing nonvision aliases |Qwen dotted/dashed131072|not rerun; GLM dotted control covers changed rule|PASS (base evidence)|
| Catalog OFF/ON/unknown controls |262144/1000000/200000|refreshOFF GLM also works; broad controls not rerun|PASS (base evidence)|

The dashed GLM name now reaches the same64K limit,16384 output budget and image request part as its dotted spelling. These are actual outgoing request values, not inferred from the screenshot.

Installed-version baseline: global qwen0.24.7 in clean profiles, catalog ON/OFF both262144; this is not a merge-base binary claim.

Regression pin: root's supplied `vision-before-red.log` has5 assertion failures and83passes/88collected; `vision-after-green.log` has88passes. I inspected those logs, but did not independently execute them. Root supplied7focused suites398passes and full build/typecheck/bundle success logs. No broad build or suite run by test engineer.

Evidence: `wire-summary.png` is a tmux capture of the on-disk request/cache ledger. Primary raw records: `before-wire.jsonl`, `after-wire.jsonl`, `after-cache-proof.json`, `after-refused-proof.json`. Matching GLM screenshots: `before-glm-dot.png`, `before-glm-dash.png`, `after-glm-dot.png`, `after-glm-dash.png`. Lifecycle: `after-life.png`, `after-restart.png`; failure/control: `after-invalid.png`, `after-refused.png`, `after-explicit-restart.png`.

Limits: no live model/backend-capacity/PDF acceptance claim; all generation stayed on loopback with dummy auth. Qwen nonvision aliases were UI-tested; image consumer comparison used GLM. Tiny invalidPNG and incomplete-provider preflights were excluded, not product failures. Screenshot review found no keys or unrelated windows. Publish only selected PNGs/summary, not local identity profiles/debug files. All owned sessions and fixture servers stopped; runnable temporary harnesses removed after preserving their source as evidence. No product source/tests changed by test engineer. No GitHub publication performed.

Post-verification identity audit: all1073current split-bundle JS hashes exactly equal the tested manifest; no added/removed/changed file, no source-hash drift, same frozen patch SHA. See `post-verification-identity-check.json`.
