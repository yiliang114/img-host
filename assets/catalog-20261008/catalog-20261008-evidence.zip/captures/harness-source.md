## drive.py

```python
import pathlib,tempfile,subprocess,shlex,json,sys,time,hashlib
out=pathlib.Path(__file__).resolve().parent; root=out.parents[3]; tm='/opt/homebrew/bin/tmux'; identity=out/'identity.json'
d=json.loads(identity.read_text()) if identity.exists() else {}
def run(*a):return subprocess.check_output([tm,*a])
action=sys.argv[1]; name=sys.argv[2]
if action in ('start','prepare'):
 model=sys.argv[3]; switch=sys.argv[4]; runtime=sys.argv[5];home=pathlib.Path(tempfile.mkdtemp(prefix='catalog-'+name+'-')); q=home/'.qwen';q.mkdir();settings={'security':{'auth':{'selectedType':'openai'},'folderTrust':{'enabled':False}},'telemetry':{'enabled':False},'general':{'disableAutoUpdate':True},'memory':{'enableManagedAutoMemory':False},'model':{'name':model}}
 if len(sys.argv)>6: settings['modelProviders']={'openai':[{'id':model,'envKey':'OPENAI_API_KEY','baseUrl':'http://127.0.0.1:'+ (out/'port.txt').read_text().strip() +'/v1','generationConfig':{'contextWindowSize':int(sys.argv[6])}}]}
 (q/'settings.json').write_text(json.dumps(settings)); env={'PATH':'/opt/homebrew/bin:/usr/bin:/bin','HOME':str(home),'QWEN_HOME':str(q),'QWEN_RUNTIME_DIR':str(q),'TERM':'tmux-256color','COLORTERM':'truecolor','FORCE_COLOR':'3','QWEN_CODE_MODELS_DEV':switch,'QWEN_CODE_MODELS_DEV_REFRESH':'off','OPENAI_API_KEY':'dummy-local-only','OPENAI_BASE_URL':'http://127.0.0.1:'+ (out/'port.txt').read_text().strip() +'/v1','OPENAI_MODEL':model,'QWEN_MODEL':model,'QWEN_SANDBOX':'false','NO_PROXY':'*','QWEN_DEBUG_LOG_FILE':'1'};cmd='cd '+shlex.quote(str(home))+' && env -i '+' '.join(shlex.quote(k+'='+v) for k,v in env.items())+' '+runtime+' --auth-type openai --model '+shlex.quote(model);session='catalog-followup-'+name;
 if action=='start':run('new-session','-d','-s',session,'-x','120','-y','40',cmd)
 d[name]={'home':str(home),'env':env,'command':cmd,'session':session};identity.write_text(json.dumps(d,indent=2));print(home)
elif action=='send':run('send-keys','-t',d[name]['session'],'C-u');run('send-keys','-t',d[name]['session'],'-l',sys.argv[3]);time.sleep(.4);run('send-keys','-t',d[name]['session'],'Enter')
elif action=='capture':
 prefix=sys.argv[3] if len(sys.argv)>3 else name
 for kind,args in [('ansi',['-e']),('pane',[]),('readable',['-S','-2000'])]:(out/(prefix+'-'+kind+'.log')).write_bytes(run('capture-pane','-p','-t',d[name]['session'],*args))
 print((out/(prefix+'-pane.log')).read_text())
elif action=='stop':run('kill-session','-t',d[name]['session'])

```

## fixture.py

```python
import http.server,json,pathlib,sys,time
out=pathlib.Path(__file__).resolve().parent
payload={'volcengine':{'models':{'doubao-seed-1-6-flash':{'id':'doubao-seed-1-6-flash','tool_call':True,'limit':{'context':131072,'output':16384},'modalities':{'input':['text'],'output':['text']}}}},'alibaba':{'models':{'qwen-flash':{'id':'qwen-flash','tool_call':True,'limit':{'context':777777,'output':32768},'modalities':{'input':['text'],'output':['text']}}}}}
for provider in ['anthropic','openai','google','deepseek','moonshotai','zai','minimax','xai','alibaba-cn']:
 payload[provider]={'models':{'fixture-'+provider:{'id':'fixture-'+provider,'tool_call':True,'limit':{'context':200000,'output':32000},'modalities':{'input':['text'],'output':['text']}}}}
def record(d):
 with (out/'wire.jsonl').open('a') as f:f.write(json.dumps(d)+'\n')
class H(http.server.BaseHTTPRequestHandler):
 def log_message(self,*a):pass
 def do_GET(self):
  record({'method':'GET','path':self.path,'ifNoneMatch':self.headers.get('If-None-Match'),'status':200});time.sleep(2);self.send_response(200);self.send_header('Content-Type','application/json');self.send_header('ETag','"fresh"');self.end_headers();self.wfile.write(b'{bad-json' if self.path.startswith('/invalid') else json.dumps(payload).encode())
 def do_POST(self):
  d=json.loads(self.rfile.read(int(self.headers.get('Content-Length','0'))));msgs=d.get('messages',[]);images=sum(1 for m in msgs if isinstance(m.get('content'),list) for c in m['content'] if c.get('type')=='image_url');record({'method':'POST','path':self.path,'model':d.get('model'),'max_tokens':d.get('max_tokens'),'imageCount':images,'stream':d.get('stream')});self.send_response(200);self.send_header('Content-Type','text/event-stream' if d.get('stream') else 'application/json');self.end_headers();usage={'prompt_tokens':1000,'completion_tokens':10,'total_tokens':1010};content='Fixture response received.'
  if d.get('stream'):
   for c in [{'choices':[{'index':0,'delta':{'content':content},'finish_reason':None}]},{'choices':[{'index':0,'delta':{},'finish_reason':'stop'}],'usage':usage}]:self.wfile.write(('data: '+json.dumps(c)+'\n\n').encode())
   self.wfile.write(b'data: [DONE]\n\n')
  else:self.wfile.write(json.dumps({'choices':[{'message':{'role':'assistant','content':content},'finish_reason':'stop'}],'usage':usage}).encode())
s=http.server.ThreadingHTTPServer(('127.0.0.1',int((out/'port.txt').read_text())),H);(out/'port.txt').write_text(str(s.server_port));s.serve_forever()

```

## render.ts

```typescript
import {TerminalCapture} from '../../../../integration-tests/terminal-capture/terminal-capture.ts';
import {resolve} from 'node:path';
const out=resolve('.qwen/e2e-tests/catalog-followup/evidence');
for(const name of process.argv.slice(2)) {
 const t=await TerminalCapture.create({cols:120,rows:40,chrome:true,title:`catalog verification: ${name}`,outputDir:out});
 try {await t.spawn('/bin/sh',['-c',`cat '${out}/${name}-ansi.log'; sleep 2`]);await t.idle();await t.capture(`${name}.png`);}finally{await t.close();}
}

```

