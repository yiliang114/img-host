import http.server,json,pathlib,sys
out=pathlib.Path(sys.argv[1]);count=0
class H(http.server.BaseHTTPRequestHandler):
 def log_message(self,*a):pass
 def do_POST(self):
  global count
  d=json.loads(self.rfile.read(int(self.headers.get('Content-Length','0'))));count+=1
  last_user=next((m for m in reversed(d.get('messages',[])) if m.get('role')=='user'),{})
  is_summary='First, reason in your <analysis>' in json.dumps(last_user) and 'state_snapshot' in json.dumps(last_user)
  content='<state_snapshot><goal>Verify deterministic context compression.</goal><progress>Loopback seed retained.</progress></state_snapshot>' if is_summary else (('history '*1000+' Seed complete.') if count==1 else 'Continued successfully after the fixture response.')
  usage={'prompt_tokens':120000 if count==1 or is_summary else 1000,'completion_tokens':40,'total_tokens':120040 if count==1 or is_summary else 1040}
  with (out/'compaction-wire-ledger.jsonl').open('a') as f:f.write(json.dumps({'index':count,'method':'POST','path':self.path,'model':d.get('model'),'max_tokens':d.get('max_tokens'),'summaryRequest':is_summary,'stream':d.get('stream'),'responseUsage':usage})+'\n')
  self.send_response(200);self.send_header('Content-Type','text/event-stream' if d.get('stream') else 'application/json');self.end_headers()
  if not d.get('stream'):
   self.wfile.write(json.dumps({'id':'fixture','object':'chat.completion','model':d.get('model'),'choices':[{'index':0,'message':{'role':'assistant','content':content},'finish_reason':'stop'}],'usage':usage}).encode());return
  chunks=[{'id':'fixture','object':'chat.completion.chunk','choices':[{'index':0,'delta':{'content':content},'finish_reason':None}]},{'id':'fixture','object':'chat.completion.chunk','choices':[{'index':0,'delta':{},'finish_reason':'stop'}],'usage':usage}]
  for c in chunks:self.wfile.write(('data: '+json.dumps(c)+'\n\n').encode())
  self.wfile.write(b'data: [DONE]\n\n')
s=http.server.ThreadingHTTPServer(('127.0.0.1',0),H);(out/'compaction-port.txt').write_text(str(s.server_port));s.serve_forever()
