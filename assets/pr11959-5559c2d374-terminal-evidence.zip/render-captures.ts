import * as path from 'node:path';
import * as fs from 'node:fs';
import { TerminalCapture } from '../../../../integration-tests/terminal-capture/terminal-capture.ts';
const directory = path.dirname(new URL(import.meta.url).pathname);
const names = process.argv.slice(2);
for (const name of names) {
  const terminal = await TerminalCapture.create({
    cols: 120,
    rows: 40,
    chrome: true,
    title: `PR #11959 · ${name} · tmux 120×40`,
    theme: 'github-dark',
    fontSize: 14,
    fontFamily: "'Menlo', monospace",
    outputDir: directory,
  });
  try {
    await terminal.spawn(process.execPath, [
      '-e',
      "setTimeout(() => process.stdout.write(require('node:fs').readFileSync(process.argv[1])), 200); setInterval(() => {}, 1000);",
      path.join(directory, `${name}-ansi.log`),
    ]);
    const raw = fs.readFileSync(path.join(directory, `${name}-ansi.log`), 'utf8');
    const marker = raw.includes('Context window:') ? 'Context window:' : raw.includes('compressed from:') ? 'compressed from:' : raw.includes('VERDICT: PASS') ? 'VERDICT: PASS' : 'Context near hard limit';
    await terminal.waitForAndIdle(marker, { timeout: 10_000, stableMs: 300 });
    await terminal.capture(`pr11959-${name}.png`);
  } finally {
    await terminal.close();
  }
}
