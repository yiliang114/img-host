# PR11959 terminal verification

Mode: exact-head evidence + matched upgrade regression at previous PR head 2b9fc537c624b333d4311c237cdda60061e53588 -> 5559c2d374957d8008f55adf40405ae0e02f8794. Catalog OFF is a control; no merge-base binary run.

Final build module realpath and SHA256: `final-runtime-identity.json`. Global isolated baseline: qwen0.24.7. All terminal captures use actual tmux120x40 keystrokes, isolated HOME/QWEN_HOME, dummy credentials.

| Case | Result | Evidence |
| --- | --- | --- |
| Catalog ON | PASS: qwen-flash 1000.0k (1,000,000) | `final-on-{ansi,pane,readable}.log` |
| Catalog OFF control | PASS: same model 262.1k (262,144) | `final-off-{ansi,pane,readable}.log` |
| Explicit provider context | PASS: 131.1k (131,072), catalog ON | `final-explicit-{ansi,pane,readable}.log` |
| Refresh disabled/offline startup | PASS: ON/OFF/explicit initialize and /context works without generation | `final-on-{ansi,pane,readable}.log` |
| Matched upgrade regression | PASS: 2b9fc old projection0 cache conditional304 -> restart131.1k; final5559 unconditional200 -> projection1/203models -> restart1000.0k | `final-upgrade-after-{ansi,pane,readable}.log` |
| Warm process/restart consistency | PASS: seed-oss-1.5 warm524.3k/max_tokens32000; refresh writes131072/65536; restart131.1k/max_tokens64000 | `final-warm / final-restarted-{ansi,pane,readable}.log` |
| Refresh connection refusal | PASS: ECONNREFUSED127.0.0.1:54727; badJSON9bytes hash unchanged; /context1000.0k; interactive input available | `final-failure-{ansi,pane,readable}.log` |
| Automatic compaction with deterministic loopback | PASS: reported usage120040 triggers hard warning; next turn compresses120049->1089, normal generation resumes; /context131.1k used1.0k safe | `final-compaction-success-{ansi,pane,readable}.log` |

Request ledgers contain model/budget/conditional headers only, no prompts or secrets. `failure-cache-proof.json` records ECONNREFUSED and unchanged cache hash.

- No merge-base binary comparison; catalog OFF is a feature control.
- Real model recognition/backend capacity/PDF acceptance NOT VERIFIED; no paid/live generation.
- Compaction uses synthetic usage accounting to exercise control flow, not a physically 120K-token conversation.
- Two earlier compaction negative attempts had fixture accounting mismatch and are not product failures.
- Screenshots rendered/inspected by parent from ANSI evidence.
