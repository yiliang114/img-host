import http.server,threading,json,pathlib,sys
out=pathlib.Path(sys.argv[1]); payload=json.loads(pathlib.Path('/tmp/pr11959-official-api.json').read_text()); release=threading.Event()
for bucket in payload.values():
 for m in bucket.get('models',{}).values():
  if 'seed-oss' in m.get('id','').lower():m['limit']={'input':131072,'context':131072,'output':65536}
payload.setdefault('volcengine',{}).setdefault('models',{})['seed-oss-1.5']={'id':'seed-oss-1.5','tool_call':True,'limit':{'input':131072,'context':131072,'output':65536},'modalities':{'input':['text'],'output':['text']}}
def record(d):
 with (out/'wire-ledger.jsonl').open('a') as f:f.write(json.dumps(d)+'\n')
class H(http.server.BaseHTTPRequestHandler):
 def log_message(self,*a):pass
 def do_GET(self):
  if self.path=='/release':release.set();self.send_response(200);self.end_headers();self.wfile.write(b'ok');return
  record({'method':'GET','path':self.path,'event':'received'})
  release.wait(8)
  body=json.dumps(payload).encode();self.send_response(200);self.send_header('Content-Type','application/json');self.end_headers()
  try:self.wfile.write(body);record({'method':'GET','path':self.path,'event':'sent','bytes':len(body)})
  except BrokenPipeError:record({'event':'client-closed'})
 def do_POST(self):
  data=json.loads(self.rfile.read(int(self.headers.get('Content-Length','0'))));record({'method':'POST','path':self.path,'model':data.get('model'),'max_tokens':data.get('max_tokens'),'max_completion_tokens':data.get('max_completion_tokens')})
  self.send_response(200);self.send_header('Content-Type','text/event-stream');self.end_headers()
  chunks=[{'id':'fixture','object':'chat.completion.chunk','choices':[{'index':0,'delta':{'content':'Fixture response. No external model called.'},'finish_reason':None}]},{'id':'fixture','object':'chat.completion.chunk','choices':[{'index':0,'delta':{},'finish_reason':'stop'}],'usage':{'prompt_tokens':1000,'completion_tokens':10,'total_tokens':1010}}]
  try:
   for c in chunks:self.wfile.write(('data: '+json.dumps(c)+'\n\n').encode())
   self.wfile.write(b'data: [DONE]\n\n')
  except BrokenPipeError:pass
server=http.server.ThreadingHTTPServer(('127.0.0.1',0),H);(out/'fixture-port.txt').write_text(str(server.server_port));server.serve_forever()
