# PR11959 TUI verification checklist

Mode: exact-head evidence + matched upgrade regression at previous PR head 2b9fc537c624b333d4311c237cdda60061e53588 -> 5559c2d374957d8008f55adf40405ae0e02f8794. Catalog OFF is a control, not merge-base.

- [x] Global baseline version0.24.7 with isolated QWEN_HOME.
- [x] Final runtime SHA and workspace core resolution/hash verified.
- [x] Catalog ON: qwen-flash 1000.0k (1,000,000).
- [x] Catalog OFF control: same model 262.1k (262,144).
- [x] Explicit provider context: 131.1k (131,072), catalog ON.
- [x] Refresh disabled/offline startup: ON/OFF/explicit initialize and /context works without generation.
- [x] Matched upgrade regression: 2b9fc old projection0 cache conditional304 -> restart131.1k; final5559 unconditional200 -> projection1/203models -> restart1000.0k.
- [x] Warm process/restart consistency: seed-oss-1.5 warm524.3k/max_tokens32000; refresh writes131072/65536; restart131.1k/max_tokens64000.
- [x] Refresh connection refusal: ECONNREFUSED127.0.0.1:54727; badJSON9bytes hash unchanged; /context1000.0k; interactive input available.
- [x] Automatic compaction with deterministic loopback: reported usage120040 triggers hard warning; next turn compresses120049->1089, normal generation resumes; /context131.1k used1.0k safe.
- [x] Primary readable/pane/ANSI captures120x40; parent handles rasterization and inspection.
- [x] Owned tmux and loopback servers stopped after evidence.

Live model recognition/backend capacity/PDF acceptance NOT VERIFIED. No paid model traffic. Fixture scripts retained as reproducibility artifacts; no product source edits.
