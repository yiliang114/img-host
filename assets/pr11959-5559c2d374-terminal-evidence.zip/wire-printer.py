import json, pathlib, hashlib, sys
p = pathlib.Path(__file__).parent
load = lambda n: json.loads((p/n).read_text())
rows = lambda n: [json.loads(s) for s in (p/n).read_text().splitlines()]
i = load('final-runtime-identity.json')
u = rows('upgrade-wire-ledger.jsonl')
w = [r for r in rows('wire-ledger.jsonl') if r['method'] == 'POST']
c = rows('compaction-wire-ledger.jsonl')
f = load('failure-cache-proof.json')
a = load('upgrade-after-refetched-cache-summary.json')
assert [r['status'] for r in u] == [304, 200]
assert u[0]['ifNoneMatch'] == '"fixed"' and u[1]['ifNoneMatch'] is None
assert [r['max_tokens'] for r in w] == [32000, 64000]
assert c[1]['summaryRequest'] is True and c[2]['summaryRequest'] is False
assert f['cacheBeforeSha256'] == f['cacheAfterSha256']
assert a['projection'] == 1 and a['models'] == 203
root = p.parents[3]
for name, expected in i['hashes'].items():
    assert hashlib.sha256((root/name).read_bytes()).hexdigest() == expected
assert '366 passed (366)' in (p/'final-core-tests.log').read_text()
print('PR #11959 - captured HTTP and persisted-state evidence')
print('HEAD: ' + i['head'])
print('Runtime: verified worktree CLI/core dist; hashes match manifest')
print('')
print('UPGRADE: same old projection0 cache and unchanged upstream ETag')
for label,r in zip(['before 2b9fc537c6','after  5559c2d374'],u):
    print(f"  {label}: GET {r['path']}  If-None-Match={r['ifNoneMatch']!r} -> {r['status']}")
print(f"  after disk: projection={a['projection']}, models={a['models']}, qwen-flash context=1000000")
print('')
print('SESSION DEFAULTS: actual loopback HTTP requests')
for label,r in zip(['warm process','new process '],w):
    print(f"  {label}: {r['model']:<16} max_tokens={r['max_tokens']}")
print('')
print('AUTOMATIC COMPACTION: synthetic usage; real client control flow')
for r in c[:3]:
    print(f"  request {r['index']}: summary={str(r['summaryRequest']):<5} max_tokens={r['max_tokens']:<5} usage.total={r['responseUsage']['total_tokens']}")
print('  TUI: ~120049 -> ~1089 tokens; normal generation resumed')
print('')
print('REFRESH FAILURE: ECONNREFUSED; malformed cache remains byte-identical')
print('  cache SHA256: ' + f['cacheAfterSha256'])
print('  TUI: bundled 1000.0k; input remains usable')
print('')
print('Regression pin: remove version checks -> 6 assertion failures; restored -> 366 passed')
print('VERDICT: PASS')
sys.stdin.readline()
