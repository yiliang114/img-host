import http.server,json,pathlib,sys
out=pathlib.Path(sys.argv[1]);raw=pathlib.Path('/tmp/pr11959-official-api.json').read_bytes()
class H(http.server.BaseHTTPRequestHandler):
 def log_message(self,*a):pass
 def do_GET(self):
  conditional=self.headers.get('If-None-Match');status=304 if conditional else 200
  with (out/'upgrade-wire-ledger.jsonl').open('a') as f:f.write(json.dumps({'method':'GET','path':self.path,'ifNoneMatch':conditional,'status':status})+'\n')
  self.send_response(status);self.send_header('Content-Type','application/json');self.send_header('ETag','"fixed"');self.end_headers()
  if status==200:self.wfile.write(raw)
s=http.server.ThreadingHTTPServer(('127.0.0.1',0),H);(out/'upgrade-port.txt').write_text(str(s.server_port));s.serve_forever()
